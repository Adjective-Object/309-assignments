#Assignment 2: Breakout

An implementation of the game breakout for A2 of CSC309 Fall 2014.

TODO:

- scoring system (back bricks worth more)
- lives? (is this even something we want done?)
- something other than Math.random() for the vertical momentum of the block after colliding with the paddle
- add more "juice" (particles, background effects)
